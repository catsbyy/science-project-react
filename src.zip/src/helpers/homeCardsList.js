const cards = [
    {
        type: 'student-type-card',
        link: '/students',
        text: 'Я - студент'
    }, 
    {
        type: 'employer-type-card',
        link: '/business',
        text: 'Я - роботодавець'
    }
];

export {cards};