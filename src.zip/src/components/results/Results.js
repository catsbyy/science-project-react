const Results = () => {
    return ( 
        <main>
            
        </main>
     );
}
 
export default Results;