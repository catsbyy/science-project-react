const Business = () => {
    return ( 
        <main class="business-body">
        </main>
     );
}
 
export default Business;