const Students = () => {
    return ( 
        <main class="students-body">
        </main>
     );
}
 
export default Students;